export const NotFoundPage = () => {
    return (
      <>
        <h1>NotFoundPage</h1>
      </>
    );
  };
